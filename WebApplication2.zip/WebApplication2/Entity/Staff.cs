﻿using System;

namespace Entity
{
    public class Class1
    {
    }
}
