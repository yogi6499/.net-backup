﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffController : ControllerBase
    {
        Respository obj = new Respository();
        // GET: api/<StaffController>
        [HttpGet]
        public IEnumerable<Staff> Get()
        {
            return obj.DisplayStaff();
        }

        // GET api/<StaffController>/5
        [HttpGet("{id}")]
        public Staff Get(int id)
        {
            Staff staff=obj.DisplayStaff().Single(m => m.StaffId == id);
            return staff;
        }

        // POST api/<StaffController>
        [HttpPost]
        public void Post([FromBody] Staff staff)
        {
            obj.Update(staff.StaffId, staff.StaffName, staff.EmailId);
        }

        // PUT api/<StaffController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Staff staff)
        {
            obj.Update(staff.StaffId, staff.StaffName, staff.EmailId);
        }

        // DELETE api/<StaffController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            obj.Delete(id);
        }
    }
}
