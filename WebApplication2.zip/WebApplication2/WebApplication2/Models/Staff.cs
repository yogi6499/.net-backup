﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class Staff
    {
        public int StaffId { get; set; }
        public string StaffName { get; set; }
        public string ContactNumber { get; set; }
        public string EmailId { get; set; }
        public string ClassType { get; set; }
    }
}
