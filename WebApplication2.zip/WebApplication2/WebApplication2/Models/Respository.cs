﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class Respository
    {
        Bll buisnessLogic = new Bll();
        public void AddStudent(Student studentModel)
        {
            
            buisnessLogic.AddStudent(studentModel);
        }

        public List<Staff> DisplayStaff()
        {
            List<Staff> sList = buisnessLogic.DisplayStaff();
            
            return sList;
        }

        public List<Student> DisplayStudent()
        {
            List<Student> sList = buisnessLogic.DisplayStudent();
            
            return sList;
        }
        public List<Student> StudentBasedOnStaff(int staffId)
        {
            List<Student> slist = buisnessLogic.StudentBasedOnStaff(staffId);

            return slist;
        }

        public void Update(int id, string number, string mailId)
        {
            buisnessLogic.Update(id, number, mailId);
        }

        internal void AssignStaff(Student studentModel)
        {
           
            buisnessLogic.AssignStaff(studentModel);
        }

        public void Delete(int id)
        {
            buisnessLogic.Delete(id);
        }
        public Student DisplayById(int id)
        {

            Student student = buisnessLogic.DisplayById(id);
           
            return student;
        }
    }
}
